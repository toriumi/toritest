#ifndef __HEXAVISION_CTL_H
#define __HEXAVISION_CTL_H

#define STHV_CAM_ADAPTER_TX1CA01 0x0001
#define STHV_CAM_ADAPTER_RPICA01 0x0002


int StHvCamOn(int CamAdapter,
	      char *DevName,
	      int CamPortNo,
	      int ImageWidth,
	      int ImageHeight,
	      int Frequency);

int StHvCamStart(int CamAdapter, char *DevName, int CamPortNo);
int StHvCamStop(int CamAdapter, char *DevName, int CamPortNo);

#endif //__HEXAVISION_CTL_H
